#define F_CPU 16000000UL

#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <util/delay.h>
#include "GLCD_Kor.h"

int Putch0(char data, FILE *fp) { while(!(UCSR0A & 0x20)); UDR0 = data; return 0;}
int Getch0(FILE *fp)  { while(!(UCSR0A & 0x80));     return UDR0; }
void UART_init(void)
{
 UCSR0A = 0x00; UCSR0B = 0x00; UCSR0C = 0x06;
 UBRR0H = 0x00; UBRR0L = 0x67;
 UCSR0B = 0x18;
 FILE *fp;  fp = fdevopen(Putch0, Getch0);
 MCU_initialize(); 
}
unsigned char number[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x98}; //���� ǥ�� 1~9
int location[] = {0B11111110, 0B11111101, 0B111111011, 0B11110111}; // FND�� �� �ڸ�(SEGMENT) //0�� ���� ���ɴϴ�.
 

int main(void)
{
	int p, r, i;
	char picth, roll, buho;

	DDRA = 0xff;
	DDRC = 0xff;

	UART_init();
	GLCD_init();
	
	cursor_flag = 0; 

	while(1)
	{
		GLCD_clear();
		for(i = 30; i > 34; i--) GLCD_Pixel(i, 63, 1);
		for(i = 60; i > 66; i--) GLCD_Pixel(32, i, 1);

		scanf("%c", &buho);
		scanf("%c", &picth);
		scanf("%c", &roll);

		switch(picth){
			case '0' : p = 1; break;
			case '1' : p = 2; break;
			case '2' : p = 3; break;
			case '3' : p = 4; break;
			case '4' : p = 5; break;
			case '5' : p = 6; break;
			case '6' : p = 7; break;
			case '7' : p = 8; break;
			case '8' : p = 9; break;
			case '9' : p = 10; break;
		}

		switch(roll){
			case '0' : r = 1; break;
			case '1' : r = 2; break;
			case '2' : r = 3; break;
			case '3' : r = 4; break;
			case '4' : r = 5; break;
			case '5' : r = 6; break;
			case '6' : r = 7; break;
			case '7' : r = 8; break;
			case '8' : r = 9; break;
			case '9' : r = 10; break;
		}
		
		switch(buho){
			case 'A' : PORTA = 0b00001110; PORTC = location[3]; for(i = 60; i > (r*5) + 6; i++) GLCD_Pixel(32, i, 1); for(i = 30; i > (p*2) + 4; i++) GLCD_Pixel(i, 63, 1); break;
			case 'B' : PORTA = 0b00111000; PORTC = location[3]; for(i = 63; i > 63 - (r*5); i--) GLCD_Pixel(32, i, 1); for(i = 30; i > (p*2) + 4; i++) GLCD_Pixel(i, 63, 1); break;
			case 'C' : PORTA = 0b00001000; PORTC = location[3]; for(i = 60; i > 66; i--) GLCD_Pixel(32, i, 1); for(i = 30; i > (p*2) + 4; i++) GLCD_Pixel(i, 63, 1); break;
			case 'D' : PORTA = 0b00000111; PORTC = location[3]; for(i = 60; i > (r*5) + 6; i++) GLCD_Pixel(32, i, 1); for(i = 32; i > 32 - (p*2); i--) GLCD_Pixel(i, 63, 1); break;
			case 'E' : PORTA = 0b00110001; PORTC = location[3]; for(i = 63; i > 63 - (r*5); i--) GLCD_Pixel(32, i, 1); for(i = 32; i > 32 - (p*2); i--) GLCD_Pixel(i, 63, 1); break;
			case 'F' : PORTA = 0b00000001; PORTC = location[3]; for(i = 60; i > 66; i--) GLCD_Pixel(32, i, 1); for(i = 32; i > 32 - (p*2); i--) GLCD_Pixel(i, 63, 1); break;
			case 'G' : PORTA = 0b00000110; PORTC = location[3]; for(i = 60; i > (r*5) + 6; i++) GLCD_Pixel(32, i, 1); for(i = 30; i > 34; i--) GLCD_Pixel(i, 63, 1); break;
			case 'H' : PORTA = 0b00110000; PORTC = location[3]; for(i = 63; i > 63 - (r*5); i--) GLCD_Pixel(32, i, 1); for(i = 30; i > 34; i--) GLCD_Pixel(i, 63, 1); break;
			case 'I' : PORTA = 0b00000000; PORTC = location[3]; for(i = 60; i > 66; i--) GLCD_Pixel(32, i, 1); for(i = 30; i > 34; i--) GLCD_Pixel(i, 63, 1);break;
		}

		buho = NULL;
		roll = NULL;
		picth = NULL;
	}

	return 0;
}
