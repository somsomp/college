﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _201531017
{
    public partial class Form1 : Form
    {
        int time_;
        private Point blankPoint;
        Button[,] A = new Button[5, 5];
        Point emp;
        Point now;

        public Form1()
        {
            InitializeComponent();
        }

        private int[] makeRandNums(int size)
        {
            Random r = new Random();

            List<int> nums = new List<int>();
            for (int i = 0; i < size; i++)
                nums.Add(i + 1);

            int[] result = new int[size];
            for (int i = 0; i < size; i++)
            {
                int index = r.Next(size - i);
                result[i] = nums[index];
                nums.RemoveAt(index);
            }

            return result;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            time_++;
            time.Text = time_.ToString();
        }

        private bool checkPuzzle()
        {
            for (int i = 0; i < 5; i++)
                for (int j = 0; j < 5; j++)
                {
                    var c = puzzlePanel.GetControlFromPosition(j, i);
                    if (c == null)
                        continue;

                    int n = (int)c.Tag;
                    if (i * 5 + (j + 1) != n)
                        return false;
                }

            return true;
        }

        private void button_result_Click(object sender, EventArgs e)
        {
            makePuzzle(5);
            if (button_result.Text == "시작")
            {
                button_result.Text = "완성";
                timer.Start();
                timer.Interval = 1000;
            }

            if (button_result.Text == "완성")
            {
                if (checkPuzzle())
                {
                    timer.Stop();
                    time_ = 0;
                    button_result.Text = "시작";
                    MessageBox.Show("퍼즐을 풀었습니다!");
                }
            }
        }

        private void makePuzzle(int size)
        {

            puzzlePanel.SuspendLayout();

            puzzlePanel.Controls.Clear();

            puzzlePanel.RowCount = size;
            puzzlePanel.ColumnCount = size;

            puzzlePanel.RowStyles.Clear();
            puzzlePanel.ColumnStyles.Clear();

            for (int i = 0; i < size; i++)
            {
                puzzlePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
                puzzlePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            }

            // 버튼 배열

            int[] nums = makeRandNums(24);
            int count = 1;
            for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
                {
                    if (count == size * size)
                        break;

                    A[i, j] = new Button();
                    A[i, j].Margin = new System.Windows.Forms.Padding(0);
                    A[i, j].Text = nums[i * size + j].ToString();
                    A[i, j].Dock = DockStyle.Fill;
                    A[i, j].Tag = nums[i * size + j];
                    A[i, j].Click += new EventHandler(button_Click);
                    puzzlePanel.Controls.Add(A[i, j], j, i);

                    count++;
                }

            puzzlePanel.ResumeLayout();

            //blankPoint = new Point(size - 1, size - 1);
        }

        void button_Click(object sender, EventArgs e)
        {
            Button button = sender as Button;
            for (int i = 0; i < A.GetLength(0); i++)
            {
                for (int y = 0; y < A.GetLength(1); y++)
                {
                    if (A[i, y].Text == " ")
                        emp = new Point(i, y);

                    if (button.Text == A[i, y].Text)
                        now = new Point(i, y);
                }

            }
            if ((int)Math.Abs((emp.X) - (now.X)) == 1 && (int)Math.Abs((emp.Y) - (now.Y)) == 0)
            {
                String eval = A[now.X, now.Y].Text;
                A[now.X, now.Y].Text = " ";
                A[emp.X, emp.Y].Text = eval;
            }
            if ((int)Math.Abs((emp.X) - (now.X)) == 0 && (int)Math.Abs((emp.Y) - (now.Y)) == 1)
            {
                String eval = A[now.X, now.Y].Text;
                A[now.X, now.Y].Text = " ";
                A[emp.X, emp.Y].Text = eval;
            }
        }
    }
}

