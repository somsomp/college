#include <iostream>
#define M 999

void floyd2(int n, const int W[7][7], int D[7][7], int P[7][7]);
//void path(int q, int r);

void main() {
	int D[7][7];
	int P[7][7];
	int W[7][7] = { 0, 4, M, M, M, 10, M,
				3, 0, M, 18, M, M, M,
				M, 6, 0, M, M, M, M,
				M, 5, 15, 0, 2, 19, 5,
				M, M, 12, 1, 0, M, M,
				M, M, M, M, M, 0, 10,
				M, M, M, 8, M, M, 0 };

	std::cout << "����" << std::endl;
	for (int i = 0; i < 7; i++) {
		for (int j = 0; j < 7; j++) {
			if (W[i][j] == 999)
				std::cout << "��\t";
			else
				std::cout << W[i][j] << "\t";
		}
		std::cout << std::endl;
	}
	std::cout << std::endl;

	floyd2(7, W, D, P);

	std::cout << std::endl;
	std::cout << "��� D" << std::endl;
	for (int i = 0; i < 7; i++) {
		for (int j = 0; j < 7; j++)
			std::cout << D[i][j] << "\t";
		std::cout << std::endl;
	}
	std::cout << std::endl;

	std::cout << "��� P" << std::endl;
	for (int i = 0; i < 7; i++) {
		for (int j = 0; j < 7; j++)
			std::cout << P[i][j] << "\t";
		std::cout << std::endl;
	}
	std::cout << std::endl;
}

void floyd2(int n, const int W[7][7], int D[7][7], int P[7][7]) {
	for (int i = 0; i < n; i++)
		for (int j = 0; j < n; j++) {
			P[i][j] = 0;
			D[i][j] = W[i][j];
		}

	for (int k = 0; k < n; k++) {
		for (int i = 0; i < n; i++)
			for (int j = 0; j < n; j++)
				if (D[i][k] + D[k][j] < D[i][j]) {
					P[i][j] = k + 1;
					D[i][j] = D[i][k] + D[k][j];
				}
		std::cout << "��� " << k + 1 << "�� ��� P" << std::endl;
		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				if (D[i][j] == 999)
					std::cout << "��\t";
				else
					std::cout << D[i][j] << "\t";
			}
			std::cout << std::endl;
		}
		std::cout << std::endl;
	}
}