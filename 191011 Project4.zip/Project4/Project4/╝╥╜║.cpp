#include <iostream>

//void print_path(int a, int b, const int P[7][7], int path[7]);

void main() {
	int path[20] = {1,};
	int P[7][7] = { 0, 0, 5, 2, 4, 0, 6,
				0, 0, 5, 0, 4, 1, 4,
				2, 0, 0, 2, 4, 2, 4,
				2, 0, 5, 0, 0, 2, 0,
				4, 4, 0, 0, 0, 4, 4,
				7, 7, 7, 7, 7, 0, 0,
				4, 4, 5, 0, 4, 4, 0 };
	int a, b, c, i = 0;


	std::cout << "�̵��� ��θ� �Է����ּ���." << std::endl;
	std::cin >> a;
	std::cin >> b;
	c = b;

	std::cout << "v" << a << "���� v" << b << "�� ���� �ִ� ��� : ";
	
	for (i = 0; path[i] >= 0; i++) {
		path[i] = b;
		b = P[a - 1][b - 1];
		if (path[i] == 0) {
			path[i] = a;
			break;
		}
	}

	for (; i >= 0; i--) {
		if (i!=0)
			std::cout << "v" << path[i] << " -> ";
		else
			std::cout << "v" << path[i];
	}
	std::cout << std::endl;
}