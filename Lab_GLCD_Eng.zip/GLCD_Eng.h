/*  * Note: Project -> Configuration options -> frequency : 16000000*/
/*   Graphic LCD Module : 128x64 dot,LED backlight           */
/* -------------------------------------------------------------------------- */
/* LCD_DATABUS PORTD : D0-D7 = DB0-DB7 (7-14, data bus)             */
/* LCD_CONTROL PORTC :                           */
/*       D0 = D/-I    (1, data/instruction)         */
/*       D1 = R/-W    (2, read/write)            */
/*                       D2 = E       (3, enable)              */
/*                       D3 = CS1     (4, chip select 1)         */
/*                       D4 = CS2     (5, chip select 2)        */
#include <avr/delay.h>
#include <stdio.h>
#include <stdlib.h>
#include "font_5x7.h"// font
#include <avr/io.h>

// Graphic LCD Port ����
#define GLCD_DATABUS PORTD // GLCD data
#define GLCD_CONTROL PORTC // GLCD control signal
#define GLCD_DATABUS_DDR DDRD
#define GLCD_CONTROL_DDR DDRC
// Graphic LCD ���ɾ� ����
#define GLCD_CS1 0x08   // GLCD_CS1 Select 0000 1000
#define GLCD_CS2 0x10   // GLCD_CS2 Select 0001 0000
#define GLCD_CS1_2 0x18   // GLCD_CS1, GLCD_CS2 Select 0001 1000
#define GLCD_START_LINE  0xC0 // 11XXXXXX: set lcd start line
#define GLCD_SET_X_ADDR  0xB8 // 10111XXX: set lcd X address
#define GLCD_SET_Y_ADDR  0x40 // 01YYYYYY: set lcd Y address
#define DISPON    0x3F
#define DISPOFF    0x3E
//

char GLCD_data[128][8]; //��ǥ�� ���� ���� ���� ����
unsigned char xcharacter, ycharacter;  // x character(0-7), y character(0-19)
unsigned char cursor_flag, xcursor, ycursor; // x and y cursor position(0-7, 0-19)
void Device_init(){
	GLCD_Port_Init();                             // initialize MCU and kit
	GLCD_Init();
	PORTF = 0x00;
	DDRF  = 0x00;
	DDRA = 0xff;   
	DDRC = 0xff;

}

void GLCD_Port_Init(void)
{ 
	GLCD_DATABUS_DDR = 0xFF;
	GLCD_CONTROL_DDR = 0xFF; 
}

void GLCD_Init()
{
	GLCD_Command( GLCD_CS1_2, DISPON );
	GLCD_Command( GLCD_CS1_2, 0xC0 ); /* ���÷��� ���۶��� */
	GLCD_Command( GLCD_CS1_2, 0xB8 ); /* X ��巹�� �� = 0 */
	GLCD_Command( GLCD_CS1_2, 0x40 ); /* Y ��巹�� �� = 0 */  
	GLCD_Clear();
}

void GLCD_Command(unsigned char signal, unsigned char command)
{
	GLCD_CONTROL = signal & 0x18; 
	GLCD_CONTROL |= 0x04; 
	GLCD_DATABUS = command; 
	_delay_us(10);
	GLCD_CONTROL &= ~0x04;
	_delay_us(10);
	GLCD_CONTROL=0x00;
	_delay_ms(1);

}
void GLCD_Data(unsigned char signal, unsigned char character)
{
	GLCD_CONTROL = (signal & 0x18) | 0x01; 
	GLCD_CONTROL |= 0x04;
	GLCD_DATABUS = character; 
	_delay_us(10);
	GLCD_CONTROL &= ~0x04;
	_delay_us(10);
	GLCD_CONTROL=0x00;
	_delay_ms(1);

}
/* clear GLCD screen */
void GLCD_Clear(void)
{
	unsigned char i, j, x;

	GLCD_CONTROL = 0x00;      // clear all control signals
	GLCD_Command(GLCD_CS1_2, DISPON);    // clear all control signals
	GLCD_Command(GLCD_CS1_2, 0xC0);    // CS1,CS2 display position
	x = GLCD_SET_X_ADDR;
	for(i = 0; i <= 7; i++)
	{
		GLCD_Command(GLCD_CS1_2, x);    // X start addtess 
		GLCD_Command(GLCD_CS1_2, GLCD_SET_Y_ADDR); // Y start address
		for(j = 0; j <= 63; j++)
		{
			GLCD_Data(GLCD_CS1_2, 0x00);   // clear CS1 and CS2 screen
		}
		x++;
	}
}

void GLCD_xy(unsigned char x, unsigned char y)       /* set character position */
{ 
	xcharacter = x;
	ycharacter = y;
	GLCD_Command(GLCD_CS1_2, 0xB8+xcharacter);   // X address
	if(ycharacter <= 9)        // if y <= 9, CS1 Y address
		GLCD_Command(GLCD_CS1, 0x40+ycharacter*6+4);
	else           // if y >= 10, CS2 Y address
		GLCD_Command(GLCD_CS2, 0x40+(ycharacter-10)*6);
}

void GLCD_Character(unsigned char character)     /* display a character */
{ 
	unsigned char i, signal, font_data;
	GLCD_xy(xcharacter,ycharacter);

	if(ycharacter <= 9)        // if y <= 9, CS1
		signal = GLCD_CS1;
	else           // if y >= 10, CS2
		signal = GLCD_CS2;

	for(i = 0; i <= 4; i++)
	{ 
		if((cursor_flag == 1) && (xcharacter == xcursor) && (ycharacter == ycursor))
			GLCD_Data(signal,(font[character - 0x20][i]) | 0x80);
		else
			GLCD_Data(signal,font[character - 0x20][i]);
	}

	GLCD_Data(signal,0x00);         // last byte 0x00
	ycharacter++;                                  // go next character position
	if(ycharacter == 20)
	{ 
		ycharacter = 0;
		xcharacter++;
	}
}

void GLCD_String(unsigned char x, unsigned char y, unsigned char *string) /* display a string */
{ 
	xcharacter = x;
	ycharacter = y;
	while(*string != '\0')
	{
		GLCD_Character(*string);   // display a charcater
		string++;
	}
}
void GLCD_Pixel(int row, int col, char color)
{
	int xadd, cs, yadd; 
	int page;


	if(col >= 0 && col < 128 && row >= 0 && row <64) //ǥ�� ������ ��ǥ�� ����
	{
		
		cs = col < 64 ? 0x08 : 0x10; // ������ǥ 64�� �������� ��� ȭ�� ����
		page = row/8; // Page�� row��ǥ�� 8�� ���� �� 
		xadd  = row%8; // xadd�� �ش� ���������� ����� ��Ʈ�ȼ��� ���� ��ġ
		yadd  = col%64; // yadd�� �ش� ȭ�鿡�� ����� ��Ʈ�ȼ��� ���� ��ġ
	

		//���� �������� �ϳ��� �ȼ����� �����Ѵ�. color�� ���� ON OFF ����
		switch(color)
		{
		case 1: GLCD_data[col][page] = GLCD_data[col][page] |  0x01<<xadd; break;
		case 0: GLCD_data[col][page] = GLCD_data[col][page] & ~(0x01<<xadd); break;
		} 
		
		 // ������ǥ 64�� �������� ��� ȭ�� ����
			GLCD_Command(cs, 0xb8|page); // page set
			GLCD_Command(cs, 0x40|yadd); // address set
			GLCD_Data(cs, GLCD_data[col][page]); // data write
		
		
	}
}
void Pixel_Clear(){
	int i, j;
	for (i = 0 ; i < 64 ; i ++ ) // page�� 0���� 7���� �ݺ�
		
	{
		for (j = 0 ; j < 128 ; j ++ ) // address�� 0���� 63���� �ݺ�
		{
			GLCD_Pixel(i, j, 0);
		}
	}
}





