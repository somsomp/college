/* ========================================================================== */
/*	  Exp19_1.c : ASCII(English)-Only Display on Graphic LCD Module           */
/* ========================================================================== */
/*   Graphic LCD Module : 128x64 dot,LED backlight   						  */
/* -------------------------------------------------------------------------- */
/* LCD_DATABUS PORTD : D0-D7 = DB0-DB7 (7-14, data bus)		      			  */
/* LCD_CONTROL PORTC :   										              */
/*						 D0 = D/-I    (1, data/instruction)		  			  */
/*						 D1 = R/-W    (2, read/write)		     			  */
/*                       D2 = E       (3, enable)			      			  */
/*                       D3 = GLCD_CS1     (4, chip select 1)		  		  */
/*                       D4 = GLCD_CS2     (5, chip select 2)		 		  */
#define F_CPU 16000000UL

#include <avr/io.h>
#include <stdlib.h>
#include <stdio.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include "GLCD_kor.h"		// define	(delay)

void uart0_init(void)  //UART0�� ��Ʈ  �������� ����
{
 UCSR0A = 0x00;
 UCSR0B = 0x00; //disable while setting baud rate
 UCSR0C = 0x06;
 UBRR0H = 0x00; //set baud rate hi
 UBRR0L = 0x67; //set baud rate lo
 UCSR0B = 0x18;
}
void Tx0char(char m) { while (((UCSR0A >> UDRE0) & 0x01) == 0); UDR0 = m; }
int Putchar(char c) { Tx0char(c); return c; }                      //���
int Getchar(void) { while ((UCSR0A & 0x80) == 0); return UDR0; }   //�Է�

//ADC initialize

// Conversion time: 104uS

void adc_init(void)

{
 ADCSRA = 0x00; //disable adc
 ADMUX  = 0x00; //select adc input 0
 ACSR   = 0x80;
 ADCSRA = 0x87;
}


//call this routine to initialize all peripherals

void init_devices(void)
{
 //stop errant interrupts until set up
 cli(); //disable all interrupts
 XMCRA = 0x00; //external memory
 XMCRB = 0x00; //external memory
 //port_init();
 //uart0_init();
 fdevopen(Putchar,0);  
 adc_init();

 MCUCR = 0x00;
 EICRA = 0x00; //extended ext ints
 EICRB = 0x00; //extended ext ints
 EIMSK = 0x00;
 TIMSK = 0x00; //timer interrupt sources
 ETIMSK = 0x00; //extended timer interrupt sources

 sei(); //re-enable interrupts
 //all peripherals are now initialized
}

// �Է����� ������ ä���� ADC�� ��ŸƮ ��Ų��.
void startConvertion(unsigned char ch)
{
	ADCSRA = ADCSRA & 0x3f;
	ADMUX = 0x60 | (ch & 0x0f);
	ADCSRA = ADCSRA | 0xc0;
}

// startConvertion() �Ŀ� ����Ǹ� ������ �� ���� �����Ѵ�.  
unsigned int readConvertData(void)
{
	volatile unsigned int temp;
	while((ADCSRA & 0x10)==0);
	ADCSRA = ADCSRA | 0x10; 
	temp = ADCL;
	//printf("ADCH = [%d] / ADCL = [%d] / Result = [%d] \n\r", ADCH, ADCL>>6,(ADCH*4+(ADCL>>6)));
	temp = ADCH;
	//temp = (ADCH*4+(ADCL>>6));
	ADCSRA = ADCSRA | 0x10; 
	return temp; 
}


int main(void)
{
	byte i=20;
	MCU_initialize();                             // initialize MCU and kit
 	//-------------------------
	uart0_init();
  	fdevopen(Putchar,Getchar); // *AVR������ �� ��������� printf �� scanf ��밡��
	printf("UART0 �� �̿��� ��� ����.\n\r");
	printf("%c\n\r", 0x0C);
	printf("��������������������������������\r\n");
	printf("�� Hyper terminal Setting                                   ��\r\n");
	printf("��----------------------------------------------------------��\r\n");
	printf("�� �ӵ�-9600, DataBit-8, Parity-����, StopBit-1, Flow-����  ��\r\n");
	printf("��������������������������������\r\n");
	
	//-------------------------
	volatile unsigned char right,left, D, X=0, Y=0, MAX=255, MIN=0;
	int SUM, tmp;
	unsigned char number[] = {0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x98}; //���� ǥ�� 1~9
	int location[] = {0B11111110, 0B11111101, 0B111111011, 0B11110111}; // FND�� �� �ڸ�(SEGMENT) //0�� ���� ���ɴϴ�.

	init_devices(); 
	DDRA = 0xff; DDRC = 0xff;


	_delay_ms(50);                                 // wait for system stabilization
	GLCD_init();

	_delay_ms(50); 
	GLCD_clear();                                 // initialize GLCD screen

	cursor_flag = 0;                              // cursor off

		/*
      GLCD_xy(0,0);				
      for(i = 0x00; i <= 0x0F; i++)
        GLCD_English(i);
      GLCD_xy(1,0);
      for(i = 0x10; i <= 0x1F; i++)
        GLCD_English(i);
      GLCD_string(2,0," !");
      GLCD_English(0x22);
      GLCD_string(2,0,"#$%&'()*+,-./");
      GLCD_string(3,0,"0123456789:;<=>?");	  
      delay_ms(5000);

      GLCD_string(0,0,"@ABCDEFGHIJKLMNO");	
      GLCD_string(1,0,"PQRSTUVWXYZ[");
      GLCD_English(0x5C);
      GLCD_string(1,13,"]^_");
      GLCD_string(2,0,"`abcdefghijklmno");
      GLCD_string(3,0,"pqrstuvwxyz{|}~");
      GLCD_English(0x7F);
      delay_ms(5000);
	  */

			for(i=16; i< 50; i++)	GLCD_Pixel( i, 10, 1);
			for(i=16; i< 50; i=i+5){
				GLCD_Pixel( i, 8, 1);
				GLCD_Pixel( i, 9, 1);
			}
			for(i=5; i<125; i++)	GLCD_Pixel(45, i, 1);
			for(i=10; i<125; i=i+10)	{ 
				GLCD_Pixel(46, i, 1); 
				GLCD_Pixel(47, i, 1);
			}
		GLCD_String(0,0,"��������ɱ��?");
			//for(i=1; i< 62; i++)	{ GLCD_Pixel( i, 1, 1);	GLCD_Pixel( i, 126, 1); }
			//for(i=1; i< 126; i++)	{ GLCD_Pixel( 1, i, 1); GLCD_Pixel( 62, i, 1); }	
	while(1)
	{
		SUM = 0;
		//for (i=0; i<10; i++) 
		{
    		startConvertion(0);			// Left sensor Converting
	    	SUM += readConvertData();
		}
		//	SUM = SUM / 10; 
		printf("ADC Value ->> [%3d]", SUM);		
		//for (tmp=0; tmp<= (int)(SUM/2); tmp++) printf(">");
		printf("\r\n");
		//printf("-> ������ : [%3d] / �Ÿ� : [%3d cm] \n\r", SUM, D);
      	
		GLCD_String(3,0," ADC value : ");
 		GLCD_English((SUM%1000)/100+48);
		GLCD_English((SUM%100)/10+48);
		GLCD_English((SUM%10+48));
	//	_delay_ms(10);
		
		if (i<120)
			i=i+3;
		else
			i=11;
		for(X=17; X<44; X++) {
			GLCD_Pixel(X, i,0);
			GLCD_Pixel(X, i+1,0);
			GLCD_Pixel(X, i+2,0);
			GLCD_Pixel(X, i+3,0);
		}
		
		GLCD_Pixel(SUM/7+16, i,1);
		GLCD_Pixel(SUM/7+16, i+1,1);
		GLCD_Pixel(SUM/7+16, i+2,1);
		GLCD_Pixel(SUM/7+17, i,1);
		GLCD_Pixel(SUM/7+17, i+1,1);	
		GLCD_Pixel(SUM/7+17, i+2,1);	
		GLCD_Pixel(SUM/7+18, i,1);
		GLCD_Pixel(SUM/7+18, i+1,1);	
		GLCD_Pixel(SUM/7+18, i+2,1);
	}

	return 0;
}
